<?php

class Home extends CI_Controller{
	
	public function index(){

		if($this->session->userdata('logged_in')){//check to see if the viewer is logged in
			$user_id = $this->session->userdata('user_id');

			$data['projects'] = $this->project_model->get_all_projects($user_id);//this will ensure whoever is logged in will only see their projects that they have personally created.

			


		}



		$data['main_view'] = 'home_view';

		$this->load->view('layouts/main', $data);

	}
}
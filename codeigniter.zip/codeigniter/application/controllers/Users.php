<?php

class Users extends CI_Controller {
	
	public function register(){

		$this->form_validation->set_rules('username','Username','trim|required|min_length[2]');//username

		$this->form_validation->set_rules('password','Password','trim|required');//password

		$this->form_validation->set_rules('confirm_password','Confirm Password','trim|required|matches[password]');//check password


		$this->form_validation->set_rules('email', 'Email', 'trim|required');//check email

		$this->form_validation->set_rules('first_name', 'First Name', 'trim|required|min_length[2]');//check email

		$this->form_validation->set_rules('last_name', 'Last Name', 'trim|required|min_length[2]');//check lastname

		if($this->form_validation->run() == FALSE){


			
			$data['main_view'] = 'users/Register_view';

			$this->load->view('layouts/main', $data);

		} else {


			if($this->user_model->create_user()){

				$this->session->set_flashdata('user_registered', 'User has been successfully registered');

				redirect('home/index');


			}else{



			}

			


		}



	}





	
	public function login(){

		//FORM VALIDATION RULES----NECESSARY! SHOULD ECHO BAD MESSAGE IF THE RULES ARE BROKEN

		$this->form_validation->set_rules('username','Username','trim|required|min_length[2]');//username

		$this->form_validation->set_rules('password','Password','trim|required');//password

		$this->form_validation->set_rules('confirm_password','Confirm Password','trim|required|matches[password]');//check password

		if($this->form_validation->run() == FALSE){

			$data = array(
				'errors' => validation_errors()

				);

			$this->session->set_flashdata($data);//automatic set and unset for data
//			$this->session->set_userdata();//set a regular session you would have to unset the data yourself

			redirect('home');
		} else {
			$username = $this->input->post('username');
			$password = $this->input->post('password');

			//create a function here that checks for this ^^^
			$user_id = $this->user_model->login_user($username, $password); ////this passes the information to the database to log the user in

			if($user_id)
			{
				//create an array of information
				$user_data = array(
					'user_id' => $user_id,
					'username' => $username,
					'logged_in' => true

								   );

				//set the array
				$this->session->set_userdata($user_data);

				//notify the user that they are logged in
				$this->session->set_flashdata('login_success', 'You are now logged in!');
				
			//	$data['main_view'] = 'admin_view';

			//	$this->load->view('layouts/main', $data);


				redirect('home/index');
				

			} 

				else {
				$this->session->set_flashdata('login_failed', 'you are not logged in');
				redirect('home/index');
			    	}
		}
		//$this->input->post('username'); code igniter way of posting data




	}
	public function logout(){
		$this->session->sess_destroy();
		redirect('home/index');
	}

/*	public function show($user_id){

		//manually, to autoload simply add the model to the autoload.php in the config file in the bottom as 'user_model'
	//	$this->load->model('user_model');
		


		$data['results'] = $this->user_model->get_users($user_id, 'kelly');//This is the communication with the User_model


		$this->load->view('User_view',$data);//This is the communication with the User_view
	/*	
		this is not the proper way of doing it, but its a good way to test your controller
		foreach ($result as $object) {
			echo $object ->username . "<br>";
		}
		this is one way to echo out the usernames in your database or any other database for that matter as long as the parameters are set.
	
	}

	public function insert() {

		$username = 'peter';
		$password = 'secret';


		$this->user_model->create_users([

			'username' => $username,
			'password' => $password






			]);
	}

	public function update() {

		$id = 5;
		$username = 'william';
		$password = 'not so secret';


		$this->user_model->update_users([

			'username' => $username,
			'password' => $password






			], $id);
	}

	public function delete(){

		$id = 5;

		$this->user_model->delete_users($id);
	}

*/



}

?>
<?php 

class User_model extends CI_Model {


	public function get_users($user_id, $username){
		
		$this->db->where([


			'id' => $user_id,
			'username' => $username

			]);

	//	$this->db->where('id', $user_id);
		
		$query = $this->db->get('users');

		return $query->result();

















		/*communicate with the database
		//manually and the automatic version is accomplished through the database.php file in the config folder like the autoload.php function.
		$config['hostname'] = "localhost";
		$config['username'] = "root";
		$config['password'] = "jackass9";
		$config['database'] = "errand_db";
		//second database manually you can load another one this way
		$config_2['hostname'] = "localhost";
		$config_2['username'] = "root_2";
		$config_2['password'] = "jackass9";
		$config_2['database'] = "errand_db2";

		$connection = $this->load->database($config);
		$connection_2 = $this->load->database($config_2);
		*/







		//$query = $this->db->query("SELECT * FROM users");
		//return $query->num_fields();//this function will spit out how many columns are in the users table in phpmyadmin
//		return $query->num_rows();//this function will spit out hwo many columns are in the users table in phpmyadmin

//		$query = $this->db->get('users');
	//	return $query->result();//the result function will return an array of objects from the database
	}

	public function create_user($data){

		$encrypted_pass = password_hash($this->input->post('password'), PASSWORD_BCRYPT);//this is to encrypt the password

		$data = array(

			'first_name' 	=>$this->input->post('first_name'),
			'last_name' 	=>$this->input->post('last_name'),
			'email' 		=>$this->input->post('email'),
			'username' 		=>$this->input->post('username'),
			'password' 		=>$encrypted_pass
			

			);

		$insert_data = $this->db->insert('users', $data);

		return $insert_data;

	}

	public function update_users($data, $id){

		$this->db->where(['id' => $id]);
		$this->db->update('users', $data);


	}

	public function delete_users($id){

		$this->db->where(['id' => $id]);
		$this->db->delete('users');

	}

	public function login_user($username, $password){


		$this->db->where('username', $username);
		
		$result = $this->db->get('users');

		$db_password = $result->row(3)->password;



		if(password_verify($password, $db_password)){//password_verify() is a native PHP function that checks the password works with PHP 5 this is to decrypt
			return $result->row(0)->id;//in my db row 0 is the row for the id if the user exists and the password is correct this will return the id number

		} else{
			return false;
		}

	}




}
















 ?>
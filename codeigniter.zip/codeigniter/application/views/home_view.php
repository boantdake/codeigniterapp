

<p class='bg-success'>

<?php if($this->session->flashdata('login_success')): ?>

<?php echo $this->session->flashdata('login_success'); ?>

<?php endif; ?>


<?php if($this->session->flashdata('user_registered')): ?>

<?php echo $this->session->flashdata('user_registered'); ?>

<?php endif; ?>

</p>

<p class='bg-danger'>

<?php if($this->session->flashdata('login_failed')): ?>

<?php echo $this->session->flashdata('login_failed'); ?>

<?php endif; ?>

<?php if($this->session->flashdata('no_access')): ?>

<?php echo $this->session->flashdata('no_access'); ?>

<?php endif; ?>


</p>

<div class="container">
<div class="jumbotron">
<div>
	<h2 class="login-page text-center">Welcome to my Project Gallery Application <weak>written in Codeigniter and PHP</weak></h2>
</div>
<div class="container">
  <br>
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
      <li data-target="#myCarousel" data-slide-to="4"></li>
      <li data-target="#myCarousel" data-slide-to="5"></li>
      <li data-target="#myCarousel" data-slide-to="6"></li>
      <li data-target="#myCarousel" data-slide-to="7"></li>
      <li data-target="#myCarousel" data-slide-to="8"></li>
      <li data-target="#myCarousel" data-slide-to="9"></li>
      <li data-target="#myCarousel" data-slide-to="10"></li>
      <li data-target="#myCarousel" data-slide-to="11"></li>
      <li data-target="#myCarousel" data-slide-to="12"></li>

    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <img class="img-responsive" src="<?php echo base_url(); ?>assets/images/projectslider/image_1.jpg" alt="LAMP Stack" width="460" height="345">
      </div>

      <div class="item">
        <img src="<?php echo base_url(); ?>assets/images/projectslider/image_2.png" alt="Ubuntu Versed" width="460" height="345">
      </div>
    
      <div class="item">
        <img src="<?php echo base_url(); ?>assets/images/projectslider/image_3.png" alt="HTML 5" width="460" height="345">
      </div>

      <div class="item">
        <img src="<?php echo base_url(); ?>assets/images/projectslider/image_4.png" alt="JavaScript" width="460" height="345">
      </div>

      <div class="item">
        <img src="<?php echo base_url(); ?>assets/images/projectslider/image_5.jpg" alt="Drupal" width="460" height="345">
      </div>

      <div class="item">
        <img src="<?php echo base_url(); ?>assets/images/projectslider/image_6.jpg" alt="Open Cart" width="460" height="345">
      </div>

      <div class="item">
        <img src="<?php echo base_url(); ?>assets/images/projectslider/image_7.jpg" alt="Wordpress" width="460" height="345">
      </div>

      <div class="item">
        <img src="<?php echo base_url(); ?>assets/images/projectslider/image_8.png" alt="PHP7" width="460" height="345">
      </div>

	  <div class="item">
        <img src="<?php echo base_url(); ?>assets/images/projectslider/image_9.jpg" alt="LPIC1 Certified" width="460" height="345">
      </div>

      <div class="item">
        <img src="<?php echo base_url(); ?>assets/images/projectslider/image_10.jpg" alt="LPIC2 Certified" width="460" height="345">
      </div>

      <div class="item">
        <img src="<?php echo base_url(); ?>assets/images/projectslider/image_11.png" alt="MCSD" width="460" height="345">
      </div>

      <div class="item">
        <img src="<?php echo base_url(); ?>assets/images/projectslider/image_12.jpg" alt="Joomla" width="460" height="345">
      </div>

      <div class="item">
        <img src="<?php echo base_url(); ?>assets/images/projectslider/image_13.jpg" alt="Zend Certified" width="460" height="345">
      </div>      
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>

</div>
</div>
<?php if(isset($projects)): ?>
<h1>Projects for <?php echo 'Bo Dake'; ?> </h1>
<table class="table table-hover"><!--shows the table data for projects as well as related data/photos-->
	
	<a class="btn btn-primary pull-right" href="<?php echo base_url();?>projects/create">Create Project</a>

	<thead>
		<tr>
		<th>
			Project name
		</th>
		<th>
			Project Description
		</th>
		

		</tr>
	</thead>
	<tbody>




		<tr>
		<?php foreach ($projects as $project): ?>
		<td><?php echo $project->project_name;?> </td>
		<td><?php echo $project->project_body;?> </td>
		<?php echo "<td><a href='". base_url() . "projects/Display/". $project->id ."'>" . "<button class='btn btn-success'>View</button>"; "</td>"?><!--redirect this to display the project itself in an actual viewing of it -->
		</tr>
		<?php endforeach; ?>


	</tbody>


</table>
<?php endif; ?>

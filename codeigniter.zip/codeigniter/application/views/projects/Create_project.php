<h2>Create Project</h2>

<?php $attributes = array('id'=>'create_form', 'class'=>'form_horizontal'); ?>

<?php echo validation_errors("<p class='bg-danger'>"); //this validation helper allows to check all of the errors on the form?>


<?php 
	echo form_open('projects/create', $attributes);///this function in code igniter will create the form attributes for you
?>

<div class="form-group">
<?php
		$data = array(

			'class' => 'form-control',
			'name' => 'project_name',
			'placeholder' => 'Project Name'
					);
	echo form_input($data);
	 ?>

</div>

<div class="form-group">
<?php
		$data = array(

			'class' => 'form-control',
			'name' => 'project_body',
			'placeholder' => 'Desc...'
					);
	echo form_textarea($data);
	 ?>

</div>

<div class="form-group">

	<?php 

		$data = array(

			'class' => 'btn btn-primary',
			'name' => 'submit',
			'value' => 'Create'
					);
	 echo form_submit($data);
	 ?>


</div>


<?php echo form_close(); ?>
<div class="container">
    <div class="col-lg-9 col-md-9 col-xs-9">


        <h1 class="project-name">Project Name: <?php echo $project_data->project_name; ?></h1>
        <p><strong>Description:</strong><br> <?php echo $project_data->project_body; ?></p>
        <p><small>Date Created: <?php echo $project_data->date_created; ?></small></p>
    
        <h3>Completed Tasks</h3>
        <hr>
            <?php if($completed_tasks): ?>
            <?php foreach($completed_tasks as $task): ?>
                <strong id="completed"><span class="glyphicon glyphicon-check"> </span><?php echo $task->task_name; ?></strong><br>
                <i><?php echo $task->task_body; ?></i><br>
            <?php endforeach; ?>

            <?php endif; ?>
    </div>
<div class="col-lg-3 col-md-3 col-xs-3">
<ul class="list-group">
	<h4>Project Actions</h4>

	<li class="list-group-item"><a href="<?php echo base_url();?>projects/create">Create Project</a></li> 
	<li class="list-group-item"><a href="<?php echo base_url();?>projects/edit/<?php echo $project_data->id; ?>">Edit Project</a></li>
	<li class="list-group-item"><a href="<?php echo base_url();?>projects/delete/<?php echo $project_data->id; ?>">Delete Project</a></li>
    <li class="list-group-item"><a href="<?php echo base_url();?>tasks/create/<?php echo $project_data->id; ?>">Create Task</a></li> 

</ul>
</div>
</div>
</div>
<div class="container">

        <div class="row">
          
            <div class="col-lg-12">
                <h1 class="page-header text-center">Project Gallery</h1>
            </div>

            <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="">
                    <img class="img-responsive" src="<?php echo base_url(); ?>assets/images/<?php echo $project_data->project_name ?>/<?php echo $project_data->image_1; ?>" />
                </a>
<!--                 <img src="<?php echo base_url(); ?>assets/images/products/<?php echo $product->image; ?>" />-->
            </div>
            <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="<?php echo base_url(); ?>assets/images/<?php echo $project_data->project_name ?>/<?php echo $project_data->image_2; ?>" />
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="<?php echo base_url(); ?>assets/images/<?php echo $project_data->project_name ?>/<?php echo $project_data->image_3; ?>" />
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="<?php echo base_url(); ?>assets/images/<?php echo $project_data->project_name ?>/<?php echo $project_data->image_4; ?>" />
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="<?php echo base_url(); ?>assets/images/<?php echo $project_data->project_name ?>/<?php echo $project_data->image_5; ?>" />
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="<?php echo base_url(); ?>assets/images/<?php echo $project_data->project_name ?>/<?php echo $project_data->image_6; ?>" />
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="<?php echo base_url(); ?>assets/images/<?php echo $project_data->project_name ?>/<?php echo $project_data->image_7; ?>" />
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#">
                    <img class="img-responsive" src="<?php echo base_url(); ?>assets/images/<?php echo $project_data->project_name ?>/<?php echo $project_data->image_8; ?>" />
                </a>
            </div>
            
        </div>


</div>
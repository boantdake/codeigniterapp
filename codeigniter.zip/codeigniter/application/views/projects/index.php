<h1>Projects Completed</h1>

<p class="bg-success"><!--Notification section to show status of actions taken -->
	<?php if($this->session->flashdata('project_deleted')): ?>

	<?php echo $this->session->flashdata('project_deleted'); ?>

	<?php endif; ?>	

	<?php if($this->session->flashdata('project_updated')): ?>

	<?php echo $this->session->flashdata('project_updated'); ?>

	<?php endif; ?>


	<?php if($this->session->flashdata('project_created')): ?>

	<?php echo $this->session->flashdata('project_created'); ?>

	<?php endif; ?>

	<?php if($this->session->flashdata('task_update')):?>
	<?php echo $this->session->flashdata('task_updated'); ?>
	<?php endif; ?>


</p>



<table class="table"><!--shows the table data for projects as well as related data/photos-->
	
	<a class="btn btn-primary pull-right" href="<?php echo base_url();?>projects/create">Create Project</a>

	<thead>
		<tr>
		<th>
			Project name
		</th>
		<th>
			Project body
		</th>
		

		</tr>
	</thead>
	<tbody>
		<tr>
		<?php foreach ($projects as $project): ?>
		<?php echo "<td><a href='". base_url() . "projects/Display/". $project->id ."'>" . $project->project_name; "</td>"?><!--this allows the project id and name to be pushed to the url -->
		<?php echo "<td>" . $project->project_body; "</td>"?>
		<td><a class="btn btn-info" href="<?php echo base_url();?>projects/Display/<?php echo $project->id; ?>"> <span class="glyphicon glyphicon-eye-open"></a></td>

		<td><a class="btn btn-danger" href="<?php echo base_url();?>projects/delete/<?php echo $project->id; ?>"><span class="glyphicon glyphicon-remove"></a></td>
		
		</tr>
		<?php endforeach; ?>


	</tbody>

</table>
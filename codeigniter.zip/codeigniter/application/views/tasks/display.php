<h1>Task Display View</h1>

<table class="table table-hover"><!--shows the table data for projects as well as related data/photos-->
	
	<a class="btn btn-primary pull-right" href="<?php echo base_url();?>projects/create">Create Project</a>

	<thead>
		<tr>
		<th>
			Task Name
		</th>
		<th>
			Task Description
		</th>
		<th>
			Created On
		</th>

		</tr>
	</thead>
	<tbody>




		<tr>
		
		<td>
		<div class="task-name">
		<?php echo $task->task_name;?> 
		</div>
		<div class="task-actions">
			<a href="<?php echo base_url(); ?>tasks/edit/<?php echo $task->id; ?>">Edit</a>

			<a href="<?php echo base_url(); ?>tasks/delete/<?php echo $task->id; ?>">Delete</a>

		</div>
		</td>

		<td><?php echo $task->task_body;?> </td>
		<td><?php echo $task->datecreated;?> </td>

		</tr>
		


	</tbody>


</table>
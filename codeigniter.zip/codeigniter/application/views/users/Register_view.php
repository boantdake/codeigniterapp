<h2>Register</h2>

<?php $attributes = array('id'=>'register_form', 'class'=>'form_horizontal'); ?>

<?php echo validation_errors("<p class='bg-danger'>"); //this validation helper allows to check all of the errors on the form?>


<?php 
	echo form_open('users/register', $attributes);///this function in code igniter will create the form attributes for you
?>

<div class="form-group">
<?php
		$data = array(

			'class' => 'form-control',
			'name' => 'first_name',
			'placeholder' => 'First Name'
					);
	echo form_input($data);
	 ?>

</div>

<div class="form-group">
<?php
		$data = array(

			'class' => 'form-control',
			'name' => 'last_name',
			'placeholder' => 'Last Name'
					);
	echo form_input($data);
	 ?>

</div>

<div class="form-group">
	<?php 

	

		$data = array(

			'class' => 'form-control',
			'name' => 'email',
			'placeholder' => 'Email'
					);
	echo form_input($data);
	 ?>

</div>






<div class="form-group">
	<?php 

	

		$data = array(

			'class' => 'form-control',
			'name' => 'username',
			'placeholder' => 'Enter Username'
					);
	echo form_input($data);
	 ?>

</div>

<div class="form-group">

	<?php 

		$data = array(

			'class' => 'form-control',
			'name' => 'password',
			'placeholder' => 'Enter Password'
					);
	echo form_password($data);
	 ?>


</div>

<div class="form-group">
	<?php  

		$data = array(

			'class' => 'form-control',
			'name' => 'confirm_password',
			'placeholder' => 'Confirm Password'
					);
	echo form_password($data);
	 ?>


</div>
<div class="form-group">

	<?php 

		$data = array(

			'class' => 'btn btn-primary',
			'name' => 'submit',
			'value' => 'Register'
					);
	 echo form_submit($data);
	 ?>


</div>

<?php echo form_close(); ?>